---
name: progress
description: |
  可视化进度面板技能 - 为 oh-my-claude 提供任务进度的可视化展示。
  支持多种展示模式：完整面板、简洁模式、统计模式。
---

# 可视化进度面板 (Progress Dashboard)

为 oh-my-claude 提供美观的任务进度可视化展示。

## 功能特性

### 1. 进度条生成

根据任务完成比例生成 ASCII 进度条：

```
进度条宽度：30 字符
满格字符：█
空格字符：░

示例：
████████████░░░░░░░░░░░░░░░░░░ 40%
```

### 2. 状态图标

| 状态 | 图标 | 含义 |
|------|------|------|
| completed | ✅ | 已完成 |
| in_progress | 🔄 | 进行中 |
| pending | ⏳ | 待处理 |
| blocked | 🚫 | 被阻塞 |
| cancelled | ❌ | 已取消 |

### 3. Agent 图标

| Agent | 图标 | 角色 |
|-------|------|------|
| 愚公 | 🏔️ | 主编排 |
| 诸葛 | 🎯 | 战略顾问 |
| 鲁班 | 🔧 | 精工巧匠 |
| 悟空 | 🔍 | 代码侦察 |
| 扁鹊 | 🩺 | Bug 诊断 |
| 墨子 | 🛡️ | 安全防御 |
| 孙子 | ⚔️ | 性能优化 |

### 4. 里程碑提示

根据完成百分比显示鼓励信息：

| 进度 | 提示 | Emoji |
|------|------|-------|
| 0-25% | 刚开始，加油！/ Just started, go! | 🚀 |
| 26-50% | 稳步推进中 / Making progress | 💪 |
| 51-75% | 过半了，胜利在望 / Halfway there! | 🎯 |
| 76-99% | 冲刺阶段！/ Final sprint! | 🏃 |
| 100% | 大功告成！/ All done! | 🎉 |

## 展示模式

### 完整模式 (Full Mode)

```
╔══════════════════════════════════════════════════════════════╗
║  🏔️ oh-my-claude 任务进度面板                                ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  📊 总体进度                                                  ║
║  ████████████░░░░░░░░░░░░░░░░░░  40% (4/10) 💪               ║
║                                                              ║
║  📋 任务列表                                                  ║
║  ✅ 分析需求                                                  ║
║  ✅ 设计架构                                                  ║
║  ✅ 创建数据模型                                              ║
║  ✅ 实现 API 端点                                             ║
║  🔄 编写单元测试 ← 当前                                       ║
║  ⏳ 集成测试                                                  ║
║  ⏳ 性能优化                                                  ║
║  ⏳ 文档更新                                                  ║
║  ⏳ 代码审查                                                  ║
║  ⏳ 部署准备                                                  ║
║                                                              ║
║  🎭 活跃 Agent: 🏔️ 愚公                                      ║
║  ⏱️ 统计: ✅ 4 | 🔄 1 | ⏳ 5                                  ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
```

### 简洁模式 (Brief Mode)

```
🏔️ 进度: ████████████░░░░░░░░░░░░░░░░░░ 40% (4/10) 💪
🔄 当前: 编写单元测试 | ⏳ 剩余: 5
```

### 统计模式 (Stats Mode)

```
📊 任务统计
├─ ✅ 已完成: 4
├─ 🔄 进行中: 1
├─ ⏳ 待处理: 5
└─ 📈 完成率: 40%
```

### 迷你模式 (Mini Mode)

单行显示，适合嵌入其他输出：

```
[████████████░░░░░░░░░░░░░░░░░░] 40% 💪
```

## 进度条生成算法

```python
def generate_progress_bar(completed, total, width=30):
    if total == 0:
        return "░" * width + " 0%"

    percent = completed / total
    filled = int(width * percent)
    empty = width - filled

    bar = "█" * filled + "░" * empty
    percentage = f"{int(percent * 100)}%"

    # 添加里程碑 emoji
    if percent >= 1.0:
        emoji = "🎉"
    elif percent >= 0.75:
        emoji = "🏃"
    elif percent >= 0.5:
        emoji = "🎯"
    elif percent >= 0.25:
        emoji = "💪"
    else:
        emoji = "🚀"

    return f"{bar} {percentage} ({completed}/{total}) {emoji}"
```

## 使用示例

### 中文

```bash
/progress        # 显示完整进度面板
/进度            # 同上
/progress brief  # 简洁模式
/面板 统计       # 统计模式
```

### English

```bash
/progress        # Show full dashboard
/dashboard       # Same as above
/progress brief  # Brief mode
/status stats    # Stats only
```

## 与其他功能集成

### 与 TodoWrite 集成

进度面板自动读取 TodoWrite 维护的任务列表：

1. 统计各状态任务数量
2. 计算完成百分比
3. 识别当前进行中的任务
4. 生成可视化输出

### 与 Agent 集成

显示当前活跃的 Agent 及其工作内容：

```
🎭 活跃 Agent
├─ 🏔️ 愚公 (主编排) → 协调整体任务
├─ 🔧 鲁班 (实现中) → 编写 UserService
└─ 🔍 悟空 (探索中) → 搜索相关代码
```

## 自定义配置

通过 `skill.json` 配置：

```json
{
  "progressStyles": {
    "full": "█",      // 满格字符
    "empty": "░",     // 空格字符
    "width": 30       // 进度条宽度
  }
}
```

## 响应语言

自动检测用户输入语言：

- 中文命令 → 中文面板
- 英文命令 → 英文面板
- 可通过参数强制指定：`/progress --lang=en`
